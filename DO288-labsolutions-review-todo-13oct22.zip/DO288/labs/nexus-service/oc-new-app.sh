#!/bin/bash

source /usr/local/etc/ocp4.config

helm install nexus3 ~/nexus-chart

